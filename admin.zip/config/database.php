<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "ecommerce_db";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_errno) {
    die("Database Connection Failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");