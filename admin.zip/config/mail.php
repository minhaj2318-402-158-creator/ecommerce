<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . "/../vendor/autoload.php";

function getMailer()
{
    $mail = new PHPMailer(true);

    $mail->isSMTP();

    $mail->Host = "smtp.gmail.com";
    $mail->SMTPAuth = true;

    // Your Gmail
    $mail->Username = "minhaj2318-402-158@bsdi-bd.org";

    // Google App Password (16 digit password)
    $mail->Password = "guat azcs jvzc bazg";

    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;

    $mail->Port = 587;

    $mail->CharSet = "UTF-8";

    $mail->isHTML(true);

    $mail->setFrom(
        "minhaj2318-402-158@bsdi-bd.org",
        "E-Commerce Website"
    );

    return $mail;
}