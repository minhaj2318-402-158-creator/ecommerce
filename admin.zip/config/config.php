<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

date_default_timezone_set("Asia/Dhaka");

require_once __DIR__ . "/database.php";