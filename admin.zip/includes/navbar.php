<nav class="navbar navbar-expand-lg navbar-dark bg-dark">

    <div class="container">

        <a class="navbar-brand" href="index.php">
            E-Commerce
        </a>


        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#menu">

            <span class="navbar-toggler-icon"></span>

        </button>


        <div
            class="collapse navbar-collapse"
            id="menu">


            <!-- SEARCH BAR -->

            <form
                action="shop.php"
                method="GET"
                class="d-flex mx-auto my-2 my-lg-0"
                style="width: 45%;">

                <input
                    type="search"
                    name="search"
                    class="form-control"
                    placeholder="Search products..."
                    value="<?= isset($_GET['search'])
                        ? htmlspecialchars($_GET['search'])
                        : '' ?>">

                <button
                    type="submit"
                    class="btn btn-primary ms-2">

                    Search

                </button>

            </form>


            <!-- NAVIGATION -->

            <ul class="navbar-nav ms-auto">


                <li class="nav-item">

                    <a
                        class="nav-link"
                        href="index.php">

                        Home

                    </a>

                </li>


                <li class="nav-item">

                    <a
                        class="nav-link"
                        href="shop.php">

                        Shop

                    </a>

                </li>


                <li class="nav-item">

                    <a
                        class="nav-link"
                        href="cart.php">

                        Cart

                    </a>

                </li>


                <?php if (isset($_SESSION['user_id'])): ?>


                    <li class="nav-item">

                        <a
                            class="nav-link"
                            href="orders.php">

                            My Orders

                        </a>

                    </li>


                    <li class="nav-item">

                        <a
                            class="nav-link"
                            href="logout.php">

                            Logout

                        </a>

                    </li>


                <?php else: ?>


                    <li class="nav-item">

                        <a
                            class="nav-link"
                            href="login.php">

                            Login

                        </a>

                    </li>


                    <li class="nav-item">

                        <a
                            class="nav-link"
                            href="register.php">

                            Register

                        </a>

                    </li>


                <?php endif; ?>


            </ul>


        </div>

    </div>

</nav>