<?php

require_once "../auth.php";

$sql = "SELECT products.*, categories.category_name
FROM products
INNER JOIN categories
ON products.category_id = categories.id
ORDER BY products.id DESC";

$result = $conn->query($sql);

if(isset($_GET['success']))
{
    echo "<div class='alert alert-success'>
    Product Added Successfully.
    </div>";
}

if(isset($_GET['updated']))
{
    echo "<div class='alert alert-success'>
    Product Updated Successfully.
    </div>";
}


if(isset($_GET['deleted']))
{
    echo "<div class='alert alert-success'>
    Product Deleted Successfully.
    </div>";
}
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<title>Products</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="d-flex justify-content-between mb-3">

<h3>Products</h3>

<a href="create.php" class="btn btn-success">

Add Product

</a>

</div>

<table class="table table-bordered table-hover">

<thead class="table-dark">

<tr>

<th>ID</th>

<th>Image</th>

<th>Name</th>

<th>Category</th>

<th>Price</th>

<th>Stock</th>

<th>Status</th>

<th>Action</th>

</tr>

</thead>

<tbody>

<?php while($row=$result->fetch_assoc()){ ?>

<tr>

<td><?= $row['id'] ?></td>

<td>

<?php if(!empty($row['image'])){ ?>

<img
src="../../assets/uploads/products/<?= htmlspecialchars($row['image']) ?>"
width="60">

<?php } ?>

</td>

<td><?= htmlspecialchars($row['product_name']) ?></td>

<td><?= htmlspecialchars($row['category_name']) ?></td>

<td><?= number_format($row['price'],2) ?></td>

<td><?= $row['quantity'] ?></td>

<td><?= htmlspecialchars($row['status']) ?></td>

<td>

<a
href="edit.php?id=<?= $row['id'] ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<a
href="delete.php?id=<?= $row['id'] ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete Product?')">

Delete

</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

<a href="../dashboard.php" class="btn btn-secondary">

Back Dashboard

</a>

</div>

</body>

</html>