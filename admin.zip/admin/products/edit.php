<?php

require_once "../auth.php";

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = (int)$_GET['id'];

$stmt = $conn->prepare("SELECT * FROM products WHERE id=? LIMIT 1");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Product not found.");
}

$product = $result->fetch_assoc();

$categories = $conn->query("
SELECT id,category_name
FROM categories
WHERE status='Active'
ORDER BY category_name ASC
");

$message = "";

if(isset($_POST['update']))
{

    $category_id = (int)$_POST['category_id'];
    $product_name = trim($_POST['product_name']);
    $description = trim($_POST['description']);
    $price = (float)$_POST['price'];
    $quantity = (int)$_POST['quantity'];
    $status = $_POST['status'];

    $slug = strtolower($product_name);
    $slug = preg_replace('/[^a-z0-9]+/','-',$slug);
    $slug = trim($slug,'-');

    $image = $product['image'];

    if(isset($_FILES['image']) && $_FILES['image']['error']==0)
    {

        $ext = strtolower(pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION));

        $allowed = ['jpg','jpeg','png','webp'];

        if(in_array($ext,$allowed))
        {

            if(!empty($product['image']))
            {
                $oldImage="../../assets/uploads/products/".$product['image'];

                if(file_exists($oldImage))
                {
                    unlink($oldImage);
                }
            }

            $image=time()."_".uniqid().".".$ext;

            move_uploaded_file(
                $_FILES['image']['tmp_name'],
                "../../assets/uploads/products/".$image
            );

        }

    }

    $update = $conn->prepare("
    UPDATE products
    SET
    category_id=?,
    product_name=?,
    product_slug=?,
    description=?,
    price=?,
    quantity=?,
    image=?,
    status=?
    WHERE id=?
    ");

    $update->bind_param(
        "isssdissi",
        $category_id,
        $product_name,
        $slug,
        $description,
        $price,
        $quantity,
        $image,
        $status,
        $id
    );

    if($update->execute())
    {
        header("Location:index.php?updated=1");
        exit();
    }
    else
    {
        $message="<div class='alert alert-danger'>
        Update Failed.
        </div>";
    }

}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Edit Product</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="card shadow">

<div class="card-header bg-warning">

<h3>Edit Product</h3>

</div>

<div class="card-body">

<?= $message ?>

<form method="POST" enctype="multipart/form-data">

<div class="mb-3">

<label>Category</label>

<select name="category_id" class="form-select" required>

<?php while($cat = $categories->fetch_assoc()){ ?>

<option
value="<?= $cat['id'] ?>"
<?= ($cat['id']==$product['category_id']) ? 'selected' : '' ?>>

<?= htmlspecialchars($cat['category_name']) ?>

</option>

<?php } ?>

</select>

</div>

<div class="mb-3">

<label>Product Name</label>

<input
type="text"
name="product_name"
class="form-control"
value="<?= htmlspecialchars($product['product_name']) ?>"
required>

</div>

<div class="mb-3">

<label>Description</label>

<textarea
name="description"
class="form-control"
rows="5"><?= htmlspecialchars($product['description']) ?></textarea>

</div>

<div class="row">

<div class="col-md-6">

<label>Price</label>

<input
type="number"
step="0.01"
name="price"
class="form-control"
value="<?= $product['price'] ?>"
required>

</div>

<div class="col-md-6">

<label>Quantity</label>

<input
type="number"
name="quantity"
class="form-control"
value="<?= $product['quantity'] ?>"
required>

</div>

</div>

<br>

<div class="mb-3">

<label>Current Image</label>

<br>

<?php if(!empty($product['image'])){ ?>

<img
src="../../assets/uploads/products/<?= htmlspecialchars($product['image']) ?>"
width="120"
class="img-thumbnail">

<?php }else{ ?>

<p>No Image</p>

<?php } ?>

</div>

<div class="mb-3">

<label>Change Image</label>

<input
type="file"
name="image"
class="form-control"
accept=".jpg,.jpeg,.png,.webp">

</div>

<div class="mb-3">

<label>Status</label>

<select
name="status"
class="form-select">

<option
value="Active"
<?= ($product['status']=="Active") ? "selected" : "" ?>>

Active

</option>

<option
value="Inactive"
<?= ($product['status']=="Inactive") ? "selected" : "" ?>>

Inactive

</option>

</select>

</div>

<button
type="submit"
name="update"
class="btn btn-warning">

Update Product

</button>

<a
href="index.php"
class="btn btn-secondary">

Back

</a>

</form>

</div>

</div>

</div>

</body>

</html>