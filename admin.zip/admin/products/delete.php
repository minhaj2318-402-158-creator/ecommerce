<?php

require_once "../auth.php";

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = (int)$_GET['id'];

// Product Load
$stmt = $conn->prepare("SELECT image FROM products WHERE id=? LIMIT 1");
$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows == 0) {
    header("Location: index.php");
    exit();
}

$product = $result->fetch_assoc();

// Delete Image
if (!empty($product['image'])) {

    $imagePath = "../../assets/uploads/products/" . $product['image'];

    if (file_exists($imagePath)) {
        unlink($imagePath);
    }
}

// Delete Product
$delete = $conn->prepare("DELETE FROM products WHERE id=?");
$delete->bind_param("i", $id);

if ($delete->execute()) {

    header("Location: index.php?deleted=1");
    exit();

} else {

    echo "Delete Failed.";

}