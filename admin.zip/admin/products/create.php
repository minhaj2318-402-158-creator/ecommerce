<?php

require_once "../auth.php";

$message = "";

// Load Categories
$categories = $conn->query("SELECT id, category_name FROM categories WHERE status='Active' ORDER BY category_name ASC");

if (isset($_POST['save'])) {

    $category_id = (int)$_POST['category_id'];
    $product_name = trim($_POST['product_name']);
    $description = trim($_POST['description']);
    $price = (float)$_POST['price'];
    $quantity = (int)$_POST['quantity'];
    $status = $_POST['status'];

    // Slug
    $slug = strtolower($product_name);
    $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
    $slug = trim($slug, '-');

    // Image Upload
    $image = "";

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {

        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));

        $allow = ['jpg','jpeg','png','webp'];

        if (in_array($ext, $allow)) {

            $image = time() . "_" . uniqid() . "." . $ext;

            move_uploaded_file(
                $_FILES['image']['tmp_name'],
                "../../assets/uploads/products/" . $image
            );
        }
    }

    $stmt = $conn->prepare("
    INSERT INTO products
    (
        category_id,
        product_name,
        product_slug,
        description,
        price,
        quantity,
        image,
        status
    )
    VALUES
    (?,?,?,?,?,?,?,?)
    ");

    $stmt->bind_param(
        "isssdiss",
        $category_id,
        $product_name,
        $slug,
        $description,
        $price,
        $quantity,
        $image,
        $status
    );

    if ($stmt->execute()) {

        header("Location: index.php?success=1");
        exit();

    } else {

        $message = "<div class='alert alert-danger'>Failed to save product.</div>";

    }
}

?>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Add Product</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="card shadow">

<div class="card-header bg-success text-white">

<h3>Add Product</h3>

</div>

<div class="card-body">

<?= $message ?>

<form method="POST" enctype="multipart/form-data">

<div class="mb-3">

<label>Category</label>

<select name="category_id" class="form-select" required>

<option value="">Select Category</option>

<?php while($cat = $categories->fetch_assoc()){ ?>

<option value="<?= $cat['id'] ?>">

<?= htmlspecialchars($cat['category_name']) ?>

</option>

<?php } ?>

</select>

</div>

<div class="mb-3">

<label>Product Name</label>

<input
type="text"
name="product_name"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Description</label>

<textarea
name="description"
class="form-control"
rows="4"></textarea>

</div>

<div class="row">

<div class="col-md-6">

<label>Price</label>

<input
type="number"
step="0.01"
name="price"
class="form-control"
required>

</div>

<div class="col-md-6">

<label>Quantity</label>

<input
type="number"
name="quantity"
class="form-control"
required>

</div>

</div>

<br>

<div class="mb-3">

<label>Product Image</label>

<input
type="file"
name="image"
class="form-control"
accept=".jpg,.jpeg,.png,.webp">

</div>

<div class="mb-3">

<label>Status</label>

<select
name="status"
class="form-select">

<option value="Active">Active</option>

<option value="Inactive">Inactive</option>

</select>

</div>

<button
type="submit"
name="save"
class="btn btn-success">

Save Product

</button>

<a href="index.php" class="btn btn-secondary">

Back

</a>

</form>

</div>

</div>

</div>

</body>

</html>