<?php

require_once "../config/config.php";

$message = "";

if(isset($_POST['login']))
{
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if(empty($email) || empty($password))
    {
        $message = "<div class='alert alert-danger'>
        Email and Password are required.
        </div>";
    }
    else
    {
        $stmt = $conn->prepare("
        SELECT id,name,email,password
        FROM admins
        WHERE email=?
        LIMIT 1
        ");

        $stmt->bind_param("s",$email);
        $stmt->execute();

        $result = $stmt->get_result();

        if($result->num_rows==1)
        {
            $admin = $result->fetch_assoc();

            if(password_verify($password,$admin['password']))
            {
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_name'] = $admin['name'];
                $_SESSION['admin_email'] = $admin['email'];

                header("Location: dashboard.php");
                exit();
            }
            else
            {
                $message="<div class='alert alert-danger'>
                Invalid Password.
                </div>";
            }
        }
        else
        {
            $message="<div class='alert alert-danger'>
            Invalid Email.
            </div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Admin Login</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="row justify-content-center">

<div class="col-md-4">

<div class="card shadow">

<div class="card-header bg-dark text-white text-center">

<h3>Admin Login</h3>

</div>

<div class="card-body">

<?= $message ?>

<form method="POST">

<div class="mb-3">

<label>Email</label>

<input
type="email"
name="email"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Password</label>

<input
type="password"
name="password"
class="form-control"
required>

</div>

<button
type="submit"
name="login"
class="btn btn-dark w-100">

Login

</button>

</form>

</div>

</div>

</div>

</div>

</div>

</body>

</html>