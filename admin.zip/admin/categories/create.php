<?php

require_once "../auth.php";

$message = "";

if (isset($_POST['save'])) {

    $category_name = trim($_POST['category_name']);
    $status = $_POST['status'];

    if (empty($category_name)) {
        $message = "<div class='alert alert-danger'>Category Name is required.</div>";
    } else {

        $slug = strtolower($category_name);
        $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
        $slug = trim($slug, '-');

        $check = $conn->prepare("SELECT id FROM categories WHERE category_slug=?");
        $check->bind_param("s", $slug);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {

            $message = "<div class='alert alert-warning'>Category already exists.</div>";

        } else {

            $insert = $conn->prepare("
                INSERT INTO categories
                (category_name, category_slug, status)
                VALUES (?, ?, ?)
            ");

            $insert->bind_param("sss", $category_name, $slug, $status);

            if ($insert->execute()) {

                header("Location: index.php?success=1");
                exit();

            } else {

                $message = "<div class='alert alert-danger'>Failed to save category.</div>";

            }
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Add Category</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="card shadow">

<div class="card-header bg-primary text-white">

<h3>Add Category</h3>

</div>

<div class="card-body">

<?= $message ?>

<form method="POST">

<div class="mb-3">

<label>Category Name</label>

<input
type="text"
name="category_name"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Status</label>

<select
name="status"
class="form-select">

<option value="Active">Active</option>

<option value="Inactive">Inactive</option>

</select>

</div>

<button
type="submit"
name="save"
class="btn btn-primary">

Save Category

</button>

<a href="index.php" class="btn btn-secondary">

Back

</a>

</form>

</div>

</div>

</div>

</body>

</html>