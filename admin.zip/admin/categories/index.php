<?php
require_once "../auth.php";

$result = $conn->query("SELECT * FROM categories ORDER BY id DESC");
?>


<?php
if (isset($_GET['success'])) {
    echo "<div class='alert alert-success'>Category Added Successfully.</div>";
}
?>


<?php
if(isset($_GET['updated']))
{
    echo "<div class='alert alert-success'>
    Category Updated Successfully.
    </div>";
}
?>

<?php
if (isset($_GET['deleted'])) {
    echo "<div class='alert alert-success'>
    Category Deleted Successfully.
    </div>";
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Categories</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-5">

<div class="d-flex justify-content-between mb-3">

<h3>Categories</h3>

<a href="create.php" class="btn btn-primary">
<i class="bi bi-plus-circle"></i>
Add Category
</a>

</div>

<div class="card shadow">

<div class="card-body">

<table class="table table-bordered table-hover">

<thead class="table-dark">

<tr>

<th>ID</th>
<th>Name</th>
<th>Slug</th>
<th>Status</th>
<th width="180">Action</th>

</tr>

</thead>

<tbody>

<?php while($row = $result->fetch_assoc()) { ?>

<tr>

<td><?= $row['id']; ?></td>

<td><?= htmlspecialchars($row['category_name']); ?></td>

<td><?= htmlspecialchars($row['category_slug']); ?></td>

<td><?= htmlspecialchars($row['status']); ?></td>

<td>

<a href="edit.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">

Edit

</a>

<a
href="delete.php?id=<?= $row['id']; ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete this category?')">

Delete

</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

<br>

<a href="../dashboard.php" class="btn btn-secondary">

← Back to Dashboard

</a>

</div>

</body>
</html>