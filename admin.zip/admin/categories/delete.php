<?php

require_once "../auth.php";

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = (int)$_GET['id'];

// Category Existence Check
$check = $conn->prepare("SELECT id FROM categories WHERE id=?");
$check->bind_param("i", $id);
$check->execute();
$check->store_result();

if ($check->num_rows == 0) {
    header("Location: index.php");
    exit();
}

// Delete Category
$delete = $conn->prepare("DELETE FROM categories WHERE id=?");
$delete->bind_param("i", $id);

if ($delete->execute()) {
    header("Location: index.php?deleted=1");
    exit();
} else {
    echo "Delete Failed.";
}