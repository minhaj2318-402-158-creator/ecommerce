<?php

require_once "../auth.php";

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = (int)$_GET['id'];

$stmt = $conn->prepare("SELECT * FROM categories WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Category not found.");
}

$category = $result->fetch_assoc();

$message = "";

if (isset($_POST['update'])) {

    $category_name = trim($_POST['category_name']);
    $status = $_POST['status'];

    $slug = strtolower($category_name);
    $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
    $slug = trim($slug, '-');

    $check = $conn->prepare("SELECT id FROM categories WHERE category_slug=? AND id!=?");
    $check->bind_param("si", $slug, $id);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {

        $message = "<div class='alert alert-warning'>Category already exists.</div>";

    } else {

        $update = $conn->prepare("
            UPDATE categories
            SET category_name=?, category_slug=?, status=?
            WHERE id=?
        ");

        $update->bind_param(
            "sssi",
            $category_name,
            $slug,
            $status,
            $id
        );

        if ($update->execute()) {
            header("Location: index.php?updated=1");
            exit();
        } else {
            $message = "<div class='alert alert-danger'>Update failed.</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Edit Category</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="card shadow">

<div class="card-header bg-warning">

<h3>Edit Category</h3>

</div>

<div class="card-body">

<?= $message ?>

<form method="POST">

<div class="mb-3">

<label>Category Name</label>

<input
type="text"
name="category_name"
class="form-control"
value="<?= htmlspecialchars($category['category_name']) ?>"
required>

</div>

<div class="mb-3">

<label>Status</label>

<select name="status" class="form-select">

<option value="Active"
<?= $category['status']=='Active'?'selected':''; ?>>

Active

</option>

<option value="Inactive"
<?= $category['status']=='Inactive'?'selected':''; ?>>

Inactive

</option>

</select>

</div>

<button
type="submit"
name="update"
class="btn btn-warning">

Update Category

</button>

<a href="index.php" class="btn btn-secondary">

Back

</a>

</form>

</div>

</div>

</div>

</body>

</html>