<?php
require_once "../auth.php";
require_once "../../config/config.php";

// Today's Sales
$today = $conn->query("
SELECT IFNULL(SUM(total_amount),0) AS total
FROM orders
WHERE DATE(created_at)=CURDATE()
");
$todaySales = $today->fetch_assoc()['total'];

// This Month Sales
$month = $conn->query("
SELECT IFNULL(SUM(total_amount),0) AS total
FROM orders
WHERE MONTH(created_at)=MONTH(CURDATE())
AND YEAR(created_at)=YEAR(CURDATE())
");
$monthSales = $month->fetch_assoc()['total'];

// This Year Sales
$year = $conn->query("
SELECT IFNULL(SUM(total_amount),0) AS total
FROM orders
WHERE YEAR(created_at)=YEAR(CURDATE())
");
$yearSales = $year->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Reports</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="d-flex justify-content-between mb-4">

<h2>Sales Reports</h2>

<a href="../dashboard.php" class="btn btn-secondary">
Dashboard
</a>

</div>

<div class="row">

<div class="col-md-4 mb-4">

<div class="card shadow border-0">

<div class="card-body text-center">

<h5>Today's Sales</h5>

<h2 class="text-primary">
৳<?= number_format($todaySales,2) ?>
</h2>

<a href="daily.php" class="btn btn-primary mt-3">
View Report
</a>

</div>

</div>

</div>

<div class="col-md-4 mb-4">

<div class="card shadow border-0">

<div class="card-body text-center">

<h5>Monthly Sales</h5>

<h2 class="text-success">
৳<?= number_format($monthSales,2) ?>
</h2>

<a href="monthly.php" class="btn btn-success mt-3">
View Report
</a>

</div>

</div>

</div>

<div class="col-md-4 mb-4">

<div class="card shadow border-0">

<div class="card-body text-center">

<h5>Yearly Sales</h5>

<h2 class="text-danger">
৳<?= number_format($yearSales,2) ?>
</h2>

<a href="yearly.php" class="btn btn-danger mt-3">
View Report
</a>

</div>

</div>

</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>