<?php
require_once "../auth.php";
require_once "../../config/config.php";

// Current Year Orders
$result = $conn->query("
SELECT
    id,
    customer_name,
    total_amount,
    order_status,
    created_at
FROM orders
WHERE YEAR(created_at)=YEAR(CURDATE())
ORDER BY id DESC
");

// Total Yearly Sales
$total = $conn->query("
SELECT IFNULL(SUM(total_amount),0) AS total
FROM orders
WHERE YEAR(created_at)=YEAR(CURDATE())
");

$totalSales = $total->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Yearly Sales Report</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-4">

<div class="d-flex justify-content-between mb-4">

<h2>This Year Sales Report</h2>

<a href="index.php" class="btn btn-secondary">
    Back
</a>

</div>

<div class="card shadow mb-4">

<div class="card-body">

<h4 class="text-success">
Total Yearly Sales :
৳<?= number_format($totalSales,2) ?>
</h4>

</div>

</div>

<div class="card shadow">

<div class="card-body">

<table class="table table-bordered table-hover">

<thead class="table-dark">

<tr>
    <th>Order ID</th>
    <th>Customer</th>
    <th>Total</th>
    <th>Status</th>
    <th>Date</th>
</tr>

</thead>

<tbody>

<?php if($result->num_rows > 0){ ?>

<?php while($row = $result->fetch_assoc()){ ?>

<tr>

<td>#<?= $row['id'] ?></td>

<td><?= htmlspecialchars($row['customer_name']) ?></td>

<td>৳<?= number_format($row['total_amount'],2) ?></td>

<td><?= htmlspecialchars($row['order_status']) ?></td>

<td><?= $row['created_at'] ?></td>

</tr>

<?php } ?>

<?php } else { ?>

<tr>

<td colspan="5" class="text-center">
No Sales This Year.
</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>