<?php

session_start();

require_once "../config/config.php";

$error = "";
$success = "";

if (isset($_POST['register'])) {

    $name  = trim($_POST['name']);
    $email = trim($_POST['email']);
    $pass  = $_POST['password'];
    $confirm = $_POST['confirm_password'];

    if ($pass !== $confirm) {

        $error = "Passwords do not match.";

    } else {

        $stmt = $conn->prepare(
            "SELECT id FROM admins WHERE email = ?"
        );

        $stmt->bind_param("s", $email);

        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows > 0) {

            $error = "Email already exists.";

        } else {

            $password = password_hash(
                $pass,
                PASSWORD_DEFAULT
            );

            $stmt = $conn->prepare(

                "INSERT INTO admins
                (name, email, password, role, status)
                VALUES (?, ?, ?, 'admin', 1)"

            );

            $stmt->bind_param(
                "sss",
                $name,
                $email,
                $password
            );

            if ($stmt->execute()) {

                $success = "Admin account created successfully.";

            }

        }

    }

}

?>


<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>Admin Register</title>


    <link

        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"

        rel="stylesheet">


    <style>

        body {

            min-height: 100vh;

            display: flex;

            align-items: center;

            justify-content: center;

            background: linear-gradient(
                135deg,
                #0f172a,
                #2563eb
            );

        }

        .card {

            width: 100%;

            max-width: 430px;

            border: none;

            border-radius: 20px;

            box-shadow: 0 20px 50px
                rgba(0,0,0,.3);

        }

        .btn-primary {

            background: #2563eb;

            border: none;

            padding: 12px;

        }

    </style>

</head>


<body>


<div class="card p-4">


    <div class="text-center mb-4">

        <h3 class="fw-bold">

            <i class="bi bi-shield-lock"></i>

            Admin Register

        </h3>

        <p class="text-muted">

            Create your admin account

        </p>

    </div>


    <?php if ($error): ?>

        <div class="alert alert-danger">

            <?= $error ?>

        </div>

    <?php endif; ?>


    <?php if ($success): ?>

        <div class="alert alert-success">

            <?= $success ?>

        </div>

    <?php endif; ?>


    <form method="POST">


        <input

            type="text"

            name="name"

            class="form-control mb-3"

            placeholder="Full Name"

            required>


        <input

            type="email"

            name="email"

            class="form-control mb-3"

            placeholder="Email Address"

            required>


        <input

            type="password"

            name="password"

            class="form-control mb-3"

            placeholder="Password"

            required>


        <input

            type="password"

            name="confirm_password"

            class="form-control mb-3"

            placeholder="Confirm Password"

            required>


        <button

            type="submit"

            name="register"

            class="btn btn-primary w-100">

            Create Admin Account

        </button>


    </form>


    <div class="text-center mt-3">

        Already have an account?

        <a href="login.php">

            Login

        </a>

    </div>


</div>


</body>

</html>