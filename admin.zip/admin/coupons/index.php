<?php
require_once "../auth.php";
require_once "../../config/config.php";

$result = $conn->query("
SELECT *
FROM coupons
ORDER BY id DESC
");
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Coupons</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-4">

<div class="d-flex justify-content-between align-items-center mb-4">

<h2>Coupon Management</h2>

<div>

<a href="../dashboard.php" class="btn btn-secondary">
Dashboard
</a>

<a href="add.php" class="btn btn-primary">
<i class="bi bi-plus-circle"></i>
Add Coupon
</a>

</div>

</div>

<div class="card shadow">

<div class="card-body">

<table class="table table-bordered table-hover align-middle">

<thead class="table-dark">

<tr>

<th>ID</th>
<th>Coupon Code</th>
<th>Discount</th>
<th>Minimum Amount</th>
<th>Expiry</th>
<th>Status</th>
<th>Action</th>

</tr>

</thead>

<tbody>

<?php if($result->num_rows > 0){ ?>

<?php while($row = $result->fetch_assoc()){ ?>

<tr>

<td>#<?= $row['id'] ?></td>

<td>
<strong><?= htmlspecialchars($row['coupon_code']) ?></strong>
</td>

<td>

<?php
if($row['coupon_type']=="Percent"){
    echo $row['discount']."%";
}else{
    echo "৳".number_format($row['discount'],2);
}
?>

</td>

<td>
৳<?= number_format($row['minimum_amount'],2) ?>
</td>

<td>
<?= $row['expiry_date'] ?>
</td>

<td>

<?php

if($row['status']){

echo '<span class="badge bg-success">Active</span>';

}else{

echo '<span class="badge bg-danger">Inactive</span>';

}

?>

</td>

<td>

<a href="edit.php?id=<?= $row['id'] ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<a href="delete.php?id=<?= $row['id'] ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Are you sure you want to delete this coupon?')">
Delete
</a>

<a href="delete.php?id=<?= $row['id'] ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete this coupon?')">

Delete

</a>

</td>

</tr>

<?php } ?>

<?php } else { ?>

<tr>

<td colspan="7" class="text-center">

No Coupons Found.

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>