<?php
require_once "../auth.php";
require_once "../../config/config.php";

if(!isset($_GET['id'])){
    header("Location: index.php");
    exit();
}

$id = intval($_GET['id']);

$stmt = $conn->prepare("SELECT * FROM coupons WHERE id=?");
$stmt->bind_param("i",$id);
$stmt->execute();

$coupon = $stmt->get_result()->fetch_assoc();

if(!$coupon){
    die("Coupon not found.");
}

if(isset($_POST['update'])){

    $coupon_code = strtoupper(trim($_POST['coupon_code']));
    $discount = $_POST['discount'];
    $coupon_type = $_POST['coupon_type'];
    $minimum_amount = $_POST['minimum_amount'];
    $expiry_date = $_POST['expiry_date'];
    $status = isset($_POST['status']) ? 1 : 0;

    $update = $conn->prepare("
    UPDATE coupons
    SET
        coupon_code=?,
        discount=?,
        coupon_type=?,
        minimum_amount=?,
        expiry_date=?,
        status=?
    WHERE id=?
    ");

    $update->bind_param(
        "sdsdsii",
        $coupon_code,
        $discount,
        $coupon_type,
        $minimum_amount,
        $expiry_date,
        $status,
        $id
    );

    if($update->execute()){
        header("Location: index.php");
        exit();
    }else{
        $error = "Failed to update coupon.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Edit Coupon</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="card shadow">

<div class="card-header bg-warning">

<h4>Edit Coupon</h4>

</div>

<div class="card-body">

<?php if(isset($error)){ ?>

<div class="alert alert-danger">
<?= $error ?>
</div>

<?php } ?>

<form method="POST">

<div class="mb-3">

<label>Coupon Code</label>

<input
type="text"
name="coupon_code"
class="form-control"
value="<?= htmlspecialchars($coupon['coupon_code']) ?>"
required>

</div>

<div class="mb-3">

<label>Discount</label>

<input
type="number"
step="0.01"
name="discount"
class="form-control"
value="<?= $coupon['discount'] ?>"
required>

</div>

<div class="mb-3">

<label>Coupon Type</label>

<select
name="coupon_type"
class="form-select">

<option value="Fixed"
<?= $coupon['coupon_type']=="Fixed"?"selected":"" ?>>

Fixed Amount

</option>

<option value="Percent"
<?= $coupon['coupon_type']=="Percent"?"selected":"" ?>>

Percentage

</option>

</select>

</div>

<div class="mb-3">

<label>Minimum Order Amount</label>

<input
type="number"
step="0.01"
name="minimum_amount"
class="form-control"
value="<?= $coupon['minimum_amount'] ?>">

</div>

<div class="mb-3">

<label>Expiry Date</label>

<input
type="date"
name="expiry_date"
class="form-control"
value="<?= $coupon['expiry_date'] ?>"
required>

</div>

<div class="form-check mb-3">

<input
type="checkbox"
class="form-check-input"
name="status"
<?= $coupon['status'] ? "checked" : "" ?>>

<label class="form-check-label">

Active

</label>

</div>

<button
type="submit"
name="update"
class="btn btn-primary">

Update Coupon

</button>

<a
href="index.php"
class="btn btn-secondary">

Cancel

</a>

</form>

</div>

</div>

</div>

</body>
</html>