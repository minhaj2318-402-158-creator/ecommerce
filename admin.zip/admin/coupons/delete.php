<?php
require_once "../auth.php";
require_once "../../config/config.php";

if(!isset($_GET['id'])){
    header("Location: index.php");
    exit();
}

$id = intval($_GET['id']);

$stmt = $conn->prepare("DELETE FROM coupons WHERE id=?");
$stmt->bind_param("i", $id);

if($stmt->execute()){
    header("Location: index.php");
    exit();
}else{
    die("Failed to delete coupon.");
}
?>