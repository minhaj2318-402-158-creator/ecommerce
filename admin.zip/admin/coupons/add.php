<?php
require_once "../auth.php";
require_once "../../config/config.php";

if(isset($_POST['save'])){

    $coupon_code = strtoupper(trim($_POST['coupon_code']));
    $discount = $_POST['discount'];
    $coupon_type = $_POST['coupon_type'];
    $minimum_amount = $_POST['minimum_amount'];
    $expiry_date = $_POST['expiry_date'];
    $status = isset($_POST['status']) ? 1 : 0;

    // Check Duplicate Coupon
    $check = $conn->prepare("SELECT id FROM coupons WHERE coupon_code=?");
    $check->bind_param("s",$coupon_code);
    $check->execute();
    $check->store_result();

    if($check->num_rows > 0){

        $error = "Coupon code already exists.";

    }else{

        $stmt = $conn->prepare("
        INSERT INTO coupons
        (coupon_code,discount,coupon_type,minimum_amount,expiry_date,status)
        VALUES(?,?,?,?,?,?)
        ");

        $stmt->bind_param(
            "sdsdsi",
            $coupon_code,
            $discount,
            $coupon_type,
            $minimum_amount,
            $expiry_date,
            $status
        );

        if($stmt->execute()){

            header("Location: index.php");
            exit();

        }else{

            $error="Failed to save coupon.";

        }

    }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Add Coupon</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="card shadow">

<div class="card-header bg-primary text-white">

<h4>Add New Coupon</h4>

</div>

<div class="card-body">

<?php if(isset($error)){ ?>

<div class="alert alert-danger">

<?= $error ?>

</div>

<?php } ?>

<form method="POST">

<div class="mb-3">

<label>Coupon Code</label>

<input
type="text"
name="coupon_code"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Discount</label>

<input
type="number"
step="0.01"
name="discount"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Coupon Type</label>

<select
name="coupon_type"
class="form-select">

<option value="Fixed">Fixed Amount</option>

<option value="Percent">Percentage</option>

</select>

</div>

<div class="mb-3">

<label>Minimum Order Amount</label>

<input
type="number"
step="0.01"
name="minimum_amount"
value="0"
class="form-control">

</div>

<div class="mb-3">

<label>Expiry Date</label>

<input
type="date"
name="expiry_date"
class="form-control"
required>

</div>

<div class="form-check mb-3">

<input
class="form-check-input"
type="checkbox"
name="status"
checked>

<label class="form-check-label">

Active

</label>

</div>

<button
type="submit"
name="save"
class="btn btn-success">

Save Coupon

</button>

<a
href="index.php"
class="btn btn-secondary">

Cancel

</a>

</form>

</div>

</div>

</div>

</body>
</html>