<?php
require_once "auth.php";
require_once "../config/config.php";

// ==========================
// Dashboard Statistics
// ==========================

// Total Users
$user = $conn->query("SELECT COUNT(*) AS total FROM users");
$totalUsers = $user->fetch_assoc()['total'];

// Total Categories
$category = $conn->query("SELECT COUNT(*) AS total FROM categories");
$totalCategories = $category->fetch_assoc()['total'];

// Total Products
$product = $conn->query("SELECT COUNT(*) AS total FROM products");
$totalProducts = $product->fetch_assoc()['total'];

// Total Orders
$order = $conn->query("SELECT COUNT(*) AS total FROM orders");
$totalOrders = $order->fetch_assoc()['total'];

// Total Revenue
$revenue = $conn->query("
SELECT IFNULL(SUM(total_amount),0) AS total
FROM orders
");

$totalRevenue = $revenue->fetch_assoc()['total'];

// Latest Orders
$latestOrders = $conn->query("
SELECT
id,
customer_name,
total_amount,
order_status,
created_at
FROM orders
ORDER BY id DESC
LIMIT 5
");

// Low Stock Products
$lowStock = $conn->query("
SELECT
id,
name,
stock,
price
FROM products
WHERE stock <= 5
ORDER BY stock ASC
LIMIT 5
");
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1">

<title>Admin Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<style>

body{
background:#f5f5f5;
}

.sidebar{

position:fixed;

left:0;

top:0;

width:250px;

height:100vh;

background:#212529;

}

.sidebar h3{

color:white;

text-align:center;

padding:20px;

border-bottom:1px solid #444;

}

.sidebar a{

display:block;

color:white;

padding:15px 20px;

text-decoration:none;

}

.sidebar a:hover{

background:#0d6efd;

}

.content{

margin-left:250px;

padding:25px;

}

.card{

border:none;

border-radius:10px;

}

</style>

</head>

<body>

<div class="sidebar">

<h3>E-Commerce</h3>

<a href="dashboard.php">

<i class="bi bi-speedometer2"></i>

Dashboard

</a>

<a href="categories/index.php">

<i class="bi bi-tags"></i>

Categories

</a>

<a href="products/index.php">

<i class="bi bi-box"></i>

Products

</a>

<a href="orders/index.php">

<i class="bi bi-bag"></i>

Orders

</a>

<a href="coupons/index.php">
    <i class="bi bi-ticket-perforated"></i>
    Coupons
</a>

<a href="reports/index.php">
    <i class="bi bi-graph-up"></i>
    Reports
</a>

<a href="logout.php">

<i class="bi bi-box-arrow-right"></i>

Logout

</a>

</div>

<div class="content">

<nav class="navbar bg-white shadow rounded mb-4">

<div class="container-fluid">

<h4>

Admin Dashboard

</h4>

<div>

Welcome,

<strong>

<?= htmlspecialchars($_SESSION['admin_name']) ?>

</strong>

</div>

</div>

</nav>

<div class="row">

<div class="col-md-3 mb-4">

<div class="card shadow">

<div class="card-body text-center">

<h5>Total Users</h5>

<h2 class="text-primary">

<?= $totalUsers ?>

</h2>

</div>

</div>

</div>

<div class="col-md-3 mb-4">

<div class="card shadow">

<div class="card-body text-center">

<h5>Categories</h5>

<h2 class="text-success">

<?= $totalCategories ?>

</h2>

</div>

</div>

</div>

<div class="col-md-3 mb-4">

<div class="card shadow">

<div class="card-body text-center">

<h5>Products</h5>

<h2 class="text-warning">

<?= $totalProducts ?>

</h2>

</div>

</div>

</div>

<div class="col-md-3 mb-4">

<div class="card shadow">

<div class="card-body text-center">

<h5>Orders</h5>

<h2 class="text-danger">

<?= $totalOrders ?>

</h2>

</div>

</div>

</div>

</div>
<div class="row">

    <div class="col-md-4 mb-4">

        <div class="card shadow">

            <div class="card-body text-center">

                <h5>Total Revenue</h5>

                <h2 class="text-success">

                    ৳<?= number_format($totalRevenue,2) ?>

                </h2>

            </div>

        </div>

    </div>

</div>

<div class="card shadow">

    <div class="card-header bg-dark text-white">

        <h5 class="mb-0">

            Latest Orders

        </h5>

    </div>

    <div class="card-body">

        <?php if($latestOrders && $latestOrders->num_rows > 0){ ?>

        <table class="table table-bordered table-hover align-middle">

            <thead class="table-light">

                <tr>

                    <th>Order ID</th>

                    <th>Customer</th>

                    <th>Total</th>

                    <th>Status</th>

                    <th>Date</th>

                    <th>Action</th>

                </tr>

            </thead>

            <tbody>

            <?php while($row = $latestOrders->fetch_assoc()){ ?>


                <tr>

                    <td>#<?= $row['id'] ?></td>

                    <td><?= htmlspecialchars($row['customer_name']) ?></td>

                    <td>৳<?= number_format($row['total_amount'],2) ?></td>

                    <td>

                        <?php

                        switch($row['order_status']){

                            case "Pending":
                                echo '<span class="badge bg-warning text-dark">Pending</span>';
                                break;

                            case "Processing":
                                echo '<span class="badge bg-info">Processing</span>';
                                break;

                            case "Completed":
                                echo '<span class="badge bg-success">Completed</span>';
                                break;

                            case "Cancelled":
                                echo '<span class="badge bg-danger">Cancelled</span>';
                                break;

                            default:
                                echo '<span class="badge bg-secondary">'.$row['order_status'].'</span>';
                        }

                        ?>

                    </td>

                    <td><?= $row['created_at'] ?></td>

                    <td>

                        <a href="orders/view.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-primary">

                            View

                        </a>

                    </td>

                </tr>

            <?php } ?>

            </tbody>

        </table>

        <?php } else { ?>

            <div class="alert alert-info mb-0">

                No orders found.

            </div>

        <?php } ?>

    </div>

    </div>

</div>

<!-- এখান থেকে Low Stock Products Card শুরু -->

<div class="card shadow mt-4">

    <div class="card-header bg-danger text-white">

        <h5 class="mb-0">
            ⚠️ Low Stock Products
        </h5>

    </div>

    <div class="card-body">

        <?php if($lowStock && $lowStock->num_rows > 0){ ?>

        <table class="table table-bordered table-hover">

            <thead class="table-light">

                <tr>
                    <th>ID</th>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Stock</th>
                </tr>

            </thead>

            <tbody>

            <?php while($product = $lowStock->fetch_assoc()){ ?>

                <tr>

                    <td>#<?= $product['id'] ?></td>

                    <td><?= htmlspecialchars($product['name']) ?></td>

                    <td>৳<?= number_format($product['price'],2) ?></td>

                    <td>
                        <span class="badge bg-danger">
                            <?= $product['stock'] ?>
                        </span>
                    </td>

                </tr>

            <?php } ?>

            </tbody>

        </table>

        <?php } else { ?>

        <div class="alert alert-success mb-0">
            All products have sufficient stock.
        </div>

        <?php } ?>

    </div>

</div>

<!-- এখানেই Low Stock Products Card শেষ -->

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>