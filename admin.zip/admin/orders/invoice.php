<?php
require_once "../auth.php";
require_once "../../config/config.php";

if(!isset($_GET['id'])){
    header("Location: index.php");
    exit();
}

$order_id = intval($_GET['id']);

// Get Order Information
$stmt = $conn->prepare("
SELECT *
FROM orders
WHERE id=?
LIMIT 1
");

$stmt->bind_param("i",$order_id);
$stmt->execute();

$order = $stmt->get_result()->fetch_assoc();

if(!$order){
    die("Invoice not found.");
}

// Get Ordered Products
$item = $conn->prepare("
SELECT
product_name,
price,
quantity,
subtotal
FROM order_items
WHERE order_id=?
");

$item->bind_param("i",$order_id);
$item->execute();

$items = $item->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>
Invoice #<?= $order['id']; ?>
</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background:#f5f5f5;
}

.invoice{
    max-width:900px;
    margin:40px auto;
    background:#fff;
    padding:40px;
    border-radius:10px;
    box-shadow:0 0 15px rgba(0,0,0,.15);
}

.company{
    font-size:32px;
    font-weight:bold;
}

.invoice-title{
    font-size:30px;
    font-weight:bold;
    color:#0d6efd;
}

table th{
    background:#f8f9fa;
}

@media print{

    .no-print{
        display:none;
    }

    body{
        background:white;
    }

    .invoice{
        box-shadow:none;
        margin:0;
        max-width:100%;
    }

}

</style>

</head>

<body>

<div class="invoice">

<div class="d-flex justify-content-between align-items-center mb-4">

<div>

<div class="company">
My E-Commerce
</div>

<p class="mb-0">
Dhaka, Bangladesh
</p>

<p>
Phone: +8801700000000
</p>

</div>

<div class="text-end">

<div class="invoice-title">

INVOICE

</div>

<h5>

Invoice #<?= $order['id']; ?>

</h5>

<p>

Date :
<?= date("d M Y",strtotime($order['created_at'])) ?>

</p>

</div>

</div>

<hr>

<div class="row mb-4">

<div class="col-md-6">

<h5>Bill To</h5>

<p>

<strong>

<?= htmlspecialchars($order['customer_name']) ?>

</strong>

<br>

<?= htmlspecialchars($order['customer_email']) ?>

<br>

<?= htmlspecialchars($order['customer_phone']) ?>

<br>

<?= nl2br(htmlspecialchars($order['customer_address'])) ?>

</p>

</div>

<div class="col-md-6 text-end">

<h5>

Order Status

</h5>

<span class="badge bg-success fs-6">

<?= $order['order_status'] ?>

</span>

</div>

</div>
<table class="table table-bordered">

    <thead class="table-dark">

        <tr>

            <th>Product</th>

            <th width="120">Price</th>

            <th width="100">Quantity</th>

            <th width="150">Subtotal</th>

        </tr>

    </thead>

    <tbody>

    <?php while($row = $items->fetch_assoc()){ ?>

        <tr>

            <td><?= htmlspecialchars($row['product_name']) ?></td>

            <td>
                ৳<?= number_format($row['price'],2) ?>
            </td>

            <td>
                <?= $row['quantity'] ?>
            </td>

            <td>
                ৳<?= number_format($row['subtotal'],2) ?>
            </td>

        </tr>

    <?php } ?>

    </tbody>

    <tfoot>

        <tr>

            <th colspan="3" class="text-end">

                Grand Total

            </th>

            <th class="text-success">

                ৳<?= number_format($order['total_amount'],2) ?>

            </th>

        </tr>

    </tfoot>

</table>

<hr>

<div class="row mt-4">

    <div class="col-md-6">

        <p>

            <strong>Payment Status:</strong>

            <?= htmlspecialchars($order['order_status']) ?>

        </p>

        <p>

            Thank you for shopping with us.

        </p>

    </div>

    <div class="col-md-6 text-end">

        <h5>

            Authorized Signature

        </h5>

        <br><br>

        _______________________

    </div>

</div>

<div class="mt-4 no-print">

    <a href="view.php?id=<?= $order['id'] ?>" class="btn btn-secondary">

        Back

    </a>

    <button onclick="window.print()" class="btn btn-success">

        Print Invoice

    </button>
<hr>

<div class="row mt-5">

    <div class="col-md-6">

        <h6>Terms & Conditions</h6>

        <p class="text-muted mb-0">
            This invoice is generated automatically by the E-Commerce Management System.
            Please keep this invoice for future reference.
        </p>

    </div>

    <div class="col-md-6 text-end">

        <h6>Thank You!</h6>

        <p class="text-muted mb-0">
            We appreciate your business and hope to serve you again.
        </p>

    </div>

</div>

<hr>

<div class="text-center text-muted mb-4">

    <small>
        © <?= date('Y') ?> My E-Commerce. All Rights Reserved.
    </small>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>