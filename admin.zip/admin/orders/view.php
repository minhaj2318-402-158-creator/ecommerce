<?php
require_once "../auth.php";
require_once "../../config/config.php";

if(!isset($_GET['id'])){
    header("Location: index.php");
    exit();
}

$order_id = intval($_GET['id']);

$stmt = $conn->prepare("
SELECT *
FROM orders
WHERE id=?
LIMIT 1
");

$stmt->bind_param("i",$order_id);
$stmt->execute();

$order = $stmt->get_result()->fetch_assoc();

if(!$order){
    die("Order not found.");
}

// Update Order Status
if (isset($_POST['update_status'])) {

    $status = $_POST['order_status'];

    $stmt = $conn->prepare("
        UPDATE orders
        SET order_status=?
        WHERE id=?
    ");

    $stmt->bind_param("si", $status, $order_id);
    $stmt->execute();

    header("Location: view.php?id=".$order_id);
    exit();
}

/* Order Items */

$item = $conn->prepare("
SELECT *
FROM order_items
WHERE order_id=?
");

$item->bind_param("i",$order_id);
$item->execute();

$items = $item->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Order Details</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-4">

<div class="d-flex justify-content-between mb-3">

<h2>Order #<?= $order['id'] ?></h2>

<a href="index.php" class="btn btn-secondary">

Back

</a>

</div>

<div class="card shadow mb-4">

<div class="card-header bg-dark text-white">

Customer Information

</div>

<div class="card-body">

<table class="table">

<tr>

<th width="200">Customer Name</th>

<td><?= htmlspecialchars($order['customer_name']) ?></td>

</tr>

<tr>

<th>Email</th>

<td><?= htmlspecialchars($order['customer_email']) ?></td>

</tr>

<tr>

<th>Phone</th>

<td><?= htmlspecialchars($order['customer_phone']) ?></td>

</tr>

<tr>

<th>Address</th>

<td><?= nl2br(htmlspecialchars($order['customer_address'])) ?></td>

</tr>

<tr>

<th>Total</th>

<td>

<strong class="text-success">

৳<?= number_format($order['total_amount'],2) ?>

</strong>

</td>

</tr>

<tr>

<th>Status</th>

<td>

<span class="badge bg-primary">

<?= $order['order_status'] ?>

</span>

</td>

</tr>

<tr>

<th>Date</th>

<td><?= $order['created_at'] ?></td>

</tr>

</table>

<form method="POST" class="mt-3">

<div class="row">

<div class="col-md-6">

<select name="order_status" class="form-select">

<option value="Pending"
<?= $order['order_status']=="Pending"?"selected":"" ?>>
Pending
</option>

<option value="Processing"
<?= $order['order_status']=="Processing"?"selected":"" ?>>
Processing
</option>

<option value="Completed"
<?= $order['order_status']=="Completed"?"selected":"" ?>>
Completed
</option>

<option value="Cancelled"
<?= $order['order_status']=="Cancelled"?"selected":"" ?>>
Cancelled
</option>

</select>

</div>

<div class="col-md-3">

<button
type="submit"
name="update_status"
class="btn btn-success">

Update Status

</button>

</div>

</div>

</form>

</div>

</div>

<div class="card shadow">

<div class="card-header bg-primary text-white">

Ordered Products

</div>

<div class="card-body">

<table class="table table-bordered">

<thead>

<tr>

<th>Product</th>

<th>Price</th>

<th>Qty</th>

<th>Subtotal</th>

</tr>

</thead>

<tbody>

<?php while($row = $items->fetch_assoc()){ ?>

<tr>

<td><?= htmlspecialchars($row['product_name']) ?></td>

<td>৳<?= number_format($row['price'],2) ?></td>

<td><?= $row['quantity'] ?></td>

<td>

৳<?= number_format($row['price']*$row['quantity'],2) ?>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>