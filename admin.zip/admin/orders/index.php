<?php
require_once "../auth.php";
require_once "../../config/config.php";

$sql = "
SELECT
    orders.*,
    users.name
FROM orders
LEFT JOIN users
ON orders.user_id = users.id
ORDER BY orders.id DESC
";

$result = $conn->query($sql);

if (!$result) {
    die("SQL Error: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Orders</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

</head>
<body class="bg-light">
<div class="container-fluid mt-4">

<div class="d-flex justify-content-between align-items-center mb-3">

<h2>Orders</h2>

<a href="../dashboard.php" class="btn btn-secondary">
Back Dashboard
</a>

</div>

<div class="card shadow">

<div class="card-body">

<table class="table table-bordered table-hover">

<thead class="table-dark">

<tr>

<th>ID</th>

<th>Customer</th>

<th>Email</th>

<th>Phone</th>

<th>Total</th>

<th>Status</th>

<th>Date</th>

<th>Action</th>

</tr>

</thead>

<tbody>

<?php while($row = $result->fetch_assoc()){ ?>

<tr>

<td>#<?= $row['id']; ?></td>

<td><?= htmlspecialchars($row['customer_name']); ?></td>

<td><?= htmlspecialchars($row['customer_email']); ?></td>

<td><?= htmlspecialchars($row['customer_phone']); ?></td>

<td>৳<?= number_format($row['total_amount'],2); ?></td>

<td>

<?php

switch($row['order_status']){

case "Pending":
echo "<span class='badge bg-warning'>Pending</span>";
break;

case "Processing":
echo "<span class='badge bg-info'>Processing</span>";
break;

case "Completed":
echo "<span class='badge bg-success'>Completed</span>";
break;

case "Cancelled":
echo "<span class='badge bg-danger'>Cancelled</span>";
break;

default:
echo "<span class='badge bg-secondary'>Unknown</span>";

}

?>

</td>

<td><?= $row['created_at']; ?></td>

<td>

<a
href="view.php?id=<?= $row['id']; ?>"
class="btn btn-primary btn-sm">

View

</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>