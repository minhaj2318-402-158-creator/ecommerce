<?php

require_once __DIR__ . "/../config/config.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: /ecommerce/admin/login.php");
    exit();
}