<?php

session_start();

?>


<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>Admin Panel | E-Commerce</title>


    <!-- Bootstrap -->

    <link

        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"

        rel="stylesheet">


    <!-- Bootstrap Icons -->

    <link

        rel="stylesheet"

        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


    <style>

        * {
            box-sizing: border-box;
        }


        body {

            margin: 0;

            min-height: 100vh;

            font-family: Arial, sans-serif;

            background: linear-gradient(
                135deg,
                #111827,
                #1e293b,
                #0f172a
            );

            display: flex;

            align-items: center;

            justify-content: center;

        }


        .admin-wrapper {

            width: 100%;

            max-width: 1000px;

            padding: 20px;

        }


        .admin-card {

            min-height: 550px;

            background: rgba(255, 255, 255, 0.96);

            border-radius: 24px;

            overflow: hidden;

            box-shadow: 0 25px 60px rgba(0, 0, 0, 0.35);

        }


        .admin-left {

            background: linear-gradient(

                135deg,

                #2563eb,

                #1d4ed8

            );

            color: white;

            min-height: 550px;

            padding: 60px 45px;

            display: flex;

            flex-direction: column;

            justify-content: center;

        }


        .admin-logo {

            width: 75px;

            height: 75px;

            border-radius: 20px;

            background: white;

            color: #2563eb;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 38px;

            margin-bottom: 25px;

        }


        .admin-left h1 {

            font-size: 42px;

            font-weight: 700;

        }


        .admin-left p {

            font-size: 17px;

            line-height: 1.7;

            opacity: 0.9;

        }


        .feature {

            margin-top: 30px;

        }


        .feature-item {

            display: flex;

            align-items: center;

            gap: 12px;

            margin-bottom: 16px;

        }


        .feature-item i {

            font-size: 20px;

        }


        .admin-right {

            min-height: 550px;

            padding: 60px 45px;

            display: flex;

            flex-direction: column;

            justify-content: center;

        }


        .admin-right h2 {

            font-weight: 700;

            color: #111827;

        }


        .admin-right p {

            color: #6b7280;

        }


        .login-btn {

            width: 100%;

            padding: 14px;

            border-radius: 10px;

            font-size: 17px;

            font-weight: 600;

            background: #2563eb;

            border: none;

            color: white;

            transition: 0.3s;

        }


        .login-btn:hover {

            background: #1d4ed8;

            transform: translateY(-2px);

        }


        .back-btn {

            display: inline-block;

            margin-top: 20px;

            text-decoration: none;

            color: #6b7280;

            text-align: center;

        }


        .back-btn:hover {

            color: #2563eb;

        }


        @media (max-width: 768px) {


            .admin-left {

                min-height: auto;

                padding: 40px 30px;

            }


            .admin-right {

                min-height: auto;

                padding: 40px 30px;

            }


            .admin-left h1 {

                font-size: 32px;

            }


        }

    </style>

</head>


<body>


    <div class="admin-wrapper">


        <div class="admin-card">


            <div class="row g-0">


                <!-- LEFT SIDE -->

                <div class="col-lg-6">


                    <div class="admin-left">


                        <div class="admin-logo">

                            <i class="bi bi-shield-lock-fill"></i>

                        </div>


                        <h1>

                            Admin Panel

                        </h1>


                        <p>

                            Manage your e-commerce business

                            with a powerful and professional

                            administration dashboard.

                        </p>


                        <div class="feature">


                            <div class="feature-item">

                                <i class="bi bi-bar-chart-fill"></i>

                                <span>

                                    Business Analytics

                                </span>

                            </div>


                            <div class="feature-item">

                                <i class="bi bi-box-seam-fill"></i>

                                <span>

                                    Product Management

                                </span>

                            </div>


                            <div class="feature-item">

                                <i class="bi bi-cart-check-fill"></i>

                                <span>

                                    Order Management

                                </span>

                            </div>


                            <div class="feature-item">

                                <i class="bi bi-people-fill"></i>

                                <span>

                                    Customer Management

                                </span>

                            </div>


                        </div>


                    </div>


                </div>


                <!-- RIGHT SIDE -->

                <div class="col-lg-6">


                    <div class="admin-right">


                        <h2>

                            Welcome Back 👋

                        </h2>


                        <p class="mb-4">

                            Login to access your admin dashboard.

                        </p>


                        <a

                            href="login.php"

                            class="login-btn text-center text-decoration-none">

                            <i class="bi bi-box-arrow-in-right me-2"></i>

                            Login to Admin Panel

                        </a>


                        <a

                            href="../index.php"

                            class="back-btn">

                            <i class="bi bi-arrow-left me-2"></i>

                            Back to Website

                        </a>


                    </div>


                </div>


            </div>


        </div>


    </div>


</body>

</html>